import React from "react";

const MyNumber = () => {
    return <>
        <h2>my number</h2>
    </>
}

export default MyNumber;